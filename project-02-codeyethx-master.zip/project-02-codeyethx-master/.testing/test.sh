#! /bin/bash

echo "------------BEGIN TEST------------"
echo "Input to Student Program: "
echo "$1"
echo "$2"
echo "Output from Student Program: "
echo "$1 $2" | ./a.out | tee $1-$2.out
diff $1-$2.out ./.testing/$1-$2.baseline 2>&1 > /dev/null
if [ "$?" == "0" ]; then
    echo "Woohoo! Received expected output!"
    echo "-------------END TEST-------------"
    exit "0"
else
    echo "Uh-oh...there's an issue!"
    echo "Expected: ($ = line end, weird chars = non-printable characters)"
    cat -vet ./.testing/$1-$2.baseline
    echo "But got: ($ = line end, weird chars = non-printable characters)"
    cat -vet $1-$2.out
    echo "-------------END TEST-------------"
    echo "Having Difficulty? Troubleshoot: "
    echo "Did your program not produce output? Run it on your own."
    echo "Don't see a difference? Double check spaces and line endings."
    exit "1"
fi
